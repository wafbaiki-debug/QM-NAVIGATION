package com.nav3dmalaysia

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.Property
import org.maplibre.android.style.layers.PropertyFactory.circleColor
import org.maplibre.android.style.layers.PropertyFactory.circleRadius
import org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor
import org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth
import org.maplibre.android.style.layers.PropertyFactory.lineCap
import org.maplibre.android.style.layers.PropertyFactory.lineColor
import org.maplibre.android.style.layers.PropertyFactory.lineJoin
import org.maplibre.android.style.layers.PropertyFactory.lineWidth
import org.maplibre.android.style.sources.GeoJsonSource
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    companion object {
        private const val REQUEST_LOCATION = 410
        private const val MAP_STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"
        private const val ROUTE_SOURCE = "nav-route-source"
        private const val ROUTE_LAYER = "nav-route-layer"
        private const val CAMERA_SOURCE = "nav-camera-source"
        private const val CAMERA_LAYER = "nav-camera-layer"
        private const val USER_SOURCE = "nav-user-source"
        private const val USER_LAYER = "nav-user-layer"
        private const val EMPTY_FEATURE_COLLECTION = "{\"type\":\"FeatureCollection\",\"features\":[]}"
        private const val CAMERA_ALERT_METERS = 500.0
    }

    private lateinit var mapView: MapView
    private lateinit var destinationInput: EditText
    private lateinit var statusText: TextView
    private lateinit var nextTurnText: TextView
    private lateinit var instructionsText: TextView
    private lateinit var cameraButton: Button
    private var map: MapLibreMap? = null
    private var currentStyle: Style? = null
    private var currentLocation: Location? = null
    private var destination: GeoPoint? = null
    private var currentRoute: RouteResult? = null
    private var currentStepIndex = 0
    private var cameraPoints: List<SpeedCamera> = emptyList()
    private val warnedCameraIds = mutableSetOf<Long>()
    private var is3D = true
    private var cameraWarningsEnabled = true
    private var followGps = true
    private var tts: TextToSpeech? = null
    private val networkExecutor = Executors.newFixedThreadPool(3)
    private lateinit var locationManager: LocationManager

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            currentLocation = location
            updateUserMarker(location)
            if (followGps && currentRoute != null) {
                val bearing = if (location.hasBearing()) location.bearing.toDouble() else (map?.cameraPosition?.bearing ?: 0.0)
                map?.animateCamera(
                    CameraUpdateFactory.newCameraPosition(
                        CameraPosition.Builder()
                            .target(LatLng(location.latitude, location.longitude))
                            .zoom(16.5)
                            .bearing(bearing)
                            .tilt(if (is3D) 55.0 else 0.0)
                            .build()
                    ), 500
                )
            }
            updateNavigationProgress(location)
            checkNearbySpeedCameras(location)
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated by Android")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        tts = TextToSpeech(this, this)
        buildUi(savedInstanceState)
        requestOrStartLocation()
    }

    private fun buildUi(savedInstanceState: Bundle?) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 251))
        }

        val header = TextView(this).apply {
            text = "QM NAVIGASI"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setBackgroundColor(Color.rgb(15, 23, 42))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(4))
        }
        destinationInput = EditText(this).apply {
            hint = "Destinasi (cth. KLCC, Kuala Lumpur)"
            singleLine = true
            textSize = 14f
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.WHITE)
        }
        searchRow.addView(destinationInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        val searchButton = makeButton("CARI")
        searchButton.setOnClickListener { findRoute() }
        val searchParams = LinearLayout.LayoutParams(dp(82), dp(48))
        searchParams.marginStart = dp(6)
        searchRow.addView(searchButton, searchParams)
        root.addView(searchRow, LinearLayout.LayoutParams(-1, -2))
        destinationInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                findRoute()
                true
            } else false
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(2), dp(8), dp(7))
        }
        val gpsButton = makeButton("GPS SAYA")
        gpsButton.setOnClickListener {
            followGps = true
            requestOrStartLocation()
            currentLocation?.let { focusOnLocation(it, 16.0) }
        }
        val threeDButton = makeButton("3D: ON")
        threeDButton.setOnClickListener {
            is3D = !is3D
            threeDButton.text = if (is3D) "3D: ON" else "3D: OFF"
            val current = map?.cameraPosition
            if (current != null) {
                map?.animateCamera(
                    CameraUpdateFactory.newCameraPosition(
                        CameraPosition.Builder()
                            .target(current.target)
                            .zoom(current.zoom)
                            .bearing(current.bearing)
                            .tilt(if (is3D) 55.0 else 0.0)
                            .build()
                    ), 450
                )
            }
        }
        cameraButton = makeButton("KAMERA: ON")
        cameraButton.setOnClickListener {
            cameraWarningsEnabled = !cameraWarningsEnabled
            cameraButton.text = if (cameraWarningsEnabled) "KAMERA: ON" else "KAMERA: OFF"
            refreshCameraLayer()
            statusText.text = if (cameraWarningsEnabled) {
                "Amaran kamera diaktifkan. Data kamera bergantung pada peta yang tersedia."
            } else {
                "Amaran kamera dimatikan. Pandu mengikut had laju yang ditetapkan."
            }
        }
        listOf(gpsButton, threeDButton, cameraButton).forEachIndexed { index, button ->
            val params = LinearLayout.LayoutParams(0, dp(42), if (index == 2) 1.35f else 1f)
            if (index > 0) params.marginStart = dp(5)
            controls.addView(button, params)
        }
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))

        mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottomPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(7))
            setBackgroundColor(Color.WHITE)
        }
        statusText = TextView(this).apply {
            text = "Sedang menunggu lokasi GPS. Benarkan akses lokasi untuk mula."
            textSize = 12f
            setTextColor(Color.rgb(71, 85, 105))
        }
        nextTurnText = TextView(this).apply {
            text = "Masukkan destinasi untuk mendapatkan panduan laluan."
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(15, 23, 42))
            setPadding(0, dp(5), 0, dp(5))
        }
        instructionsText = TextView(this).apply {
            text = "Arahan perjalanan akan dipaparkan di sini."
            textSize = 12f
            setTextColor(Color.rgb(51, 65, 85))
            setPadding(0, 0, dp(4), dp(4))
        }
        val instructionsScroll = ScrollView(this).apply {
            isFillViewport = false
            addView(instructionsText)
        }
        bottomPanel.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        bottomPanel.addView(nextTurnText, LinearLayout.LayoutParams(-1, -2))
        bottomPanel.addView(instructionsScroll, LinearLayout.LayoutParams(-1, dp(104)))
        root.addView(bottomPanel, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        mapView.getMapAsync { readyMap ->
            map = readyMap
            readyMap.uiSettings.isCompassEnabled = true
            readyMap.setStyle(Style.Builder().fromUri(MAP_STYLE_URL)) { style ->
                currentStyle = style
                installMapLayers(style)
                val loc = currentLocation
                if (loc != null) focusOnLocation(loc, 15.0) else {
                    readyMap.cameraPosition = CameraPosition.Builder()
                        .target(LatLng(3.1390, 101.6869))
                        .zoom(10.5)
                        .tilt(55.0)
                        .build()
                }
            }
        }
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        setPadding(dp(4), 0, dp(4), 0)
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(37, 99, 235))
    }

    private fun installMapLayers(style: Style) {
        try {
            style.addSource(GeoJsonSource(ROUTE_SOURCE, EMPTY_FEATURE_COLLECTION))
            style.addSource(GeoJsonSource(CAMERA_SOURCE, EMPTY_FEATURE_COLLECTION))
            style.addSource(GeoJsonSource(USER_SOURCE, EMPTY_FEATURE_COLLECTION))

            style.addLayer(
                LineLayer(ROUTE_LAYER, ROUTE_SOURCE).withProperties(
                    lineColor("#2563EB"),
                    lineWidth(6f),
                    lineCap(Property.LINE_CAP_ROUND),
                    lineJoin(Property.LINE_JOIN_ROUND)
                )
            )
            style.addLayer(
                CircleLayer(CAMERA_LAYER, CAMERA_SOURCE).withProperties(
                    circleRadius(8f),
                    circleColor("#DC2626"),
                    circleStrokeColor("#FFFFFF"),
                    circleStrokeWidth(2f)
                )
            )
            style.addLayer(
                CircleLayer(USER_LAYER, USER_SOURCE).withProperties(
                    circleRadius(7f),
                    circleColor("#2563EB"),
                    circleStrokeColor("#FFFFFF"),
                    circleStrokeWidth(3f)
                )
            )
            updateUserMarker(currentLocation)
            refreshCameraLayer()
        } catch (error: Exception) {
            statusText.text = "Peta dimuatkan, tetapi lapisan laluan gagal disediakan: ${error.localizedMessage ?: "ralat"}"
        }
    }

    private fun requestOrStartLocation() {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION
            )
            statusText.text = "Benarkan akses lokasi untuk mendapatkan laluan dari kedudukan anda."
            return
        }
        startLocationUpdates()
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        if (!hasLocationPermission()) return
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            for (provider in providers) {
                try {
                    if (locationManager.isProviderEnabled(provider)) {
                        locationManager.requestLocationUpdates(provider, 3000L, 5f, locationListener, Looper.getMainLooper())
                        val last = locationManager.getLastKnownLocation(provider)
                        if (last != null && (currentLocation == null || last.time > (currentLocation?.time ?: 0L))) {
                            currentLocation = last
                            updateUserMarker(last)
                            if (followGps) focusOnLocation(last, 15.0)
                        }
                    }
                } catch (_: Exception) {
                    // One provider can be unavailable while the other still works.
                }
            }
            if (currentLocation == null) statusText.text = "Mendapatkan GPS... Pastikan Location di telefon dihidupkan."
        } catch (error: SecurityException) {
            statusText.text = "Kebenaran lokasi belum diberikan."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION) {
            if (hasLocationPermission()) startLocationUpdates()
            else statusText.text = "Akses lokasi ditolak. Navigasi memerlukan lokasi asal."
        }
    }

    private fun findRoute() {
        val query = destinationInput.text.toString().trim()
        if (query.isBlank()) {
            destinationInput.error = "Masukkan destinasi"
            return
        }
        val origin = currentLocation
        if (origin == null) {
            statusText.text = "Lokasi GPS belum tersedia. Tekan GPS SAYA dan benarkan akses lokasi."
            requestOrStartLocation()
            return
        }

        statusText.text = "Mencari destinasi dan mengira laluan..."
        nextTurnText.text = "Sedang menyediakan panduan..."
        networkExecutor.execute {
            try {
                val target = geocodeDestination(query)
                val route = requestRoute(GeoPoint(origin.latitude, origin.longitude), target)
                runOnUiThread {
                    destination = target
                    currentRoute = route
                    currentStepIndex = route.steps.indexOfFirst { it.type != "depart" }.let { if (it >= 0) it else 0 }
                    warnedCameraIds.clear()
                    followGps = true
                    currentStyle?.getSourceAs<GeoJsonSource>(ROUTE_SOURCE)?.setGeoJson(route.geoJson)
                    val mid = GeoPoint(
                        (origin.latitude + target.latitude) / 2.0,
                        (origin.longitude + target.longitude) / 2.0
                    )
                    val zoom = when {
                        route.distanceMeters > 150000 -> 7.0
                        route.distanceMeters > 60000 -> 8.5
                        route.distanceMeters > 25000 -> 9.5
                        route.distanceMeters > 8000 -> 11.0
                        else -> 12.5
                    }
                    map?.animateCamera(
                        CameraUpdateFactory.newCameraPosition(
                            CameraPosition.Builder().target(LatLng(mid.latitude, mid.longitude)).zoom(zoom).tilt(if (is3D) 55.0 else 0.0).build()
                        ), 800
                    )
                    statusText.text = "${formatDistance(route.distanceMeters)} • Anggaran ${formatDuration(route.durationSeconds)} • Mencari data kamera kelajuan..."
                    nextTurnText.text = route.steps.getOrNull(currentStepIndex)?.let { "Seterusnya: ${it.instruction}" } ?: "Laluan sedia. Ikut garisan biru."
                    instructionsText.text = route.steps.mapIndexed { index, step ->
                        "${index + 1}. ${step.instruction}  (${formatDistance(step.distanceMeters)})"
                    }.joinToString("\n")
                    loadSpeedCameras(route.coordinates, route.distanceMeters)
                    tts?.speak("Laluan ditemui. Jarak ${formatDistance(route.distanceMeters)}. ${route.steps.getOrNull(currentStepIndex)?.instruction ?: "Ikut garisan biru."}", TextToSpeech.QUEUE_FLUSH, null, "route_start")
                }
            } catch (error: Exception) {
                runOnUiThread {
                    statusText.text = "Tidak dapat mencari laluan: ${error.message ?: "Semak internet dan destinasi."}"
                    nextTurnText.text = "Cuba nama tempat atau alamat yang lebih lengkap."
                }
            }
        }
    }

    private fun geocodeDestination(query: String): GeoPoint {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=my&q=$encoded")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("User-Agent", "QM-NAVIGASI/1.0 Android navigation prototype")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val results = JSONArray(body)
            if (results.length() == 0) throw IllegalStateException("Destinasi tidak ditemui di Malaysia.")
            val item = results.getJSONObject(0)
            return GeoPoint(item.getString("lat").toDouble(), item.getString("lon").toDouble())
        } finally {
            connection.disconnect()
        }
    }

    private fun requestRoute(origin: GeoPoint, target: GeoPoint): RouteResult {
        val url = URL(
            "https://router.project-osrm.org/route/v1/driving/${origin.longitude},${origin.latitude};${target.longitude},${target.latitude}" +
                "?overview=full&geometries=geojson&steps=true&alternatives=false"
        )
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20000
            readTimeout = 25000
            setRequestProperty("User-Agent", "QM-NAVIGASI/1.0 Android navigation prototype")
        }
        try {
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            if (root.optString("code") != "Ok") throw IllegalStateException("Laluan jalan raya tidak tersedia untuk destinasi ini.")
            val route = root.getJSONArray("routes").getJSONObject(0)
            val geometry = route.getJSONObject("geometry")
            val coordinateArray = geometry.getJSONArray("coordinates")
            val coordinates = mutableListOf<GeoPoint>()
            for (i in 0 until coordinateArray.length()) {
                val pair = coordinateArray.getJSONArray(i)
                coordinates.add(GeoPoint(pair.getDouble(1), pair.getDouble(0)))
            }
            val routeGeoJson = JSONObject()
                .put("type", "FeatureCollection")
                .put("features", JSONArray().put(JSONObject().put("type", "Feature").put("geometry", geometry).put("properties", JSONObject())))
                .toString()

            val steps = mutableListOf<RouteStep>()
            val legs = route.getJSONArray("legs")
            for (legIndex in 0 until legs.length()) {
                val legSteps = legs.getJSONObject(legIndex).getJSONArray("steps")
                for (i in 0 until legSteps.length()) {
                    val step = legSteps.getJSONObject(i)
                    val maneuver = step.getJSONObject("maneuver")
                    val loc = maneuver.getJSONArray("location")
                    val type = maneuver.optString("type", "continue")
                    val modifier = maneuver.optString("modifier", "")
                    val roadName = step.optString("name", "").trim()
                    steps.add(
                        RouteStep(
                            latitude = loc.getDouble(1),
                            longitude = loc.getDouble(0),
                            instruction = describeManeuver(type, modifier, roadName),
                            distanceMeters = step.optDouble("distance", 0.0),
                            type = type
                        )
                    )
                }
            }
            return RouteResult(
                geoJson = routeGeoJson,
                coordinates = coordinates,
                distanceMeters = route.optDouble("distance", 0.0),
                durationSeconds = route.optDouble("duration", 0.0),
                steps = steps
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun describeManeuver(type: String, modifier: String, road: String): String {
        val action = when (type.lowercase(Locale.ROOT)) {
            "depart" -> "Mulakan perjalanan"
            "arrive" -> "Anda tiba di destinasi"
            "turn" -> when (modifier.lowercase(Locale.ROOT)) {
                "left" -> "Belok kiri"
                "right" -> "Belok kanan"
                "slight left" -> "Belok sedikit ke kiri"
                "slight right" -> "Belok sedikit ke kanan"
                "sharp left" -> "Belok tajam ke kiri"
                "sharp right" -> "Belok tajam ke kanan"
                "uturn" -> "Buat pusingan U"
                else -> "Ikut arah jalan"
            }
            "roundabout", "rotary", "roundabout turn" -> "Masuk bulatan dan ikut arah yang ditunjukkan"
            "merge" -> "Cantum ke laluan"
            "fork" -> when (modifier.lowercase(Locale.ROOT)) {
                "left" -> "Ambil cabang kiri"
                "right" -> "Ambil cabang kanan"
                else -> "Ikut cabang yang ditunjukkan"
            }
            "on ramp" -> "Masuk ke susur"
            "off ramp" -> "Keluar melalui susur"
            "continue", "new name", "notification", "end of road" -> when (modifier.lowercase(Locale.ROOT)) {
                "left" -> "Teruskan ke kiri"
                "right" -> "Teruskan ke kanan"
                else -> "Teruskan perjalanan"
            }
            else -> "Ikut laluan yang ditunjukkan"
        }
        return if (road.isNotBlank()) "$action ke $road" else action
    }

    private fun loadSpeedCameras(routePoints: List<GeoPoint>, distanceMeters: Double) {
        if (routePoints.isEmpty()) return
        networkExecutor.execute {
            try {
                val sampleCount = min(24, max(2, ceil(distanceMeters / 2500.0).toInt()))
                val indices = (0 until sampleCount).map { i ->
                    if (sampleCount == 1) 0 else (i.toDouble() * (routePoints.size - 1) / (sampleCount - 1)).roundToInt()
                }.distinct()
                val radius = if (distanceMeters < 20000.0) 1200 else 2000
                val queryBuilder = StringBuilder("[out:json][timeout:25];(")
                indices.forEach { index ->
                    val point = routePoints[index]
                    queryBuilder.append("node(around:$radius,${point.latitude},${point.longitude})[\"highway\"=\"speed_camera\"];")
                }
                queryBuilder.append(");out body;")
                val connection = (URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("User-Agent", "QM-NAVIGASI/1.0 Android navigation prototype")
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                }
                val postData = "data=" + URLEncoder.encode(queryBuilder.toString(), "UTF-8")
                connection.outputStream.use { it.write(postData.toByteArray(Charsets.UTF_8)) }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val elements = JSONObject(body).optJSONArray("elements") ?: JSONArray()
                val cameras = LinkedHashMap<Long, SpeedCamera>()
                for (i in 0 until elements.length()) {
                    val element = elements.getJSONObject(i)
                    val tags = element.optJSONObject("tags")
                    cameras[element.optLong("id")] = SpeedCamera(
                        id = element.optLong("id"),
                        point = GeoPoint(element.getDouble("lat"), element.getDouble("lon")),
                        maxSpeed = tags?.optString("maxspeed", "") ?: ""
                    )
                }
                runOnUiThread {
                    cameraPoints = cameras.values.toList()
                    refreshCameraLayer()
                    val route = currentRoute
                    if (route != null) {
                        statusText.text = "${formatDistance(route.distanceMeters)} • Anggaran ${formatDuration(route.durationSeconds)} • ${cameraPoints.size} lokasi kamera dipetakan"
                    }
                    if (cameraPoints.isEmpty()) {
                        statusText.text = (statusText.text.toString() + " — tiada kamera ditemui dalam data peta bagi laluan ini.")
                    }
                }
            } catch (_: Exception) {
                runOnUiThread {
                    val route = currentRoute
                    if (route != null) statusText.text = "${formatDistance(route.distanceMeters)} • Anggaran ${formatDuration(route.durationSeconds)} • Data kamera tidak dapat dimuatkan sekarang."
                }
            }
        }
    }

    private fun refreshCameraLayer() {
        val visibleCameras = if (cameraWarningsEnabled) cameraPoints else emptyList()
        val features = JSONArray()
        visibleCameras.forEach { camera ->
            val feature = JSONObject()
                .put("type", "Feature")
                .put("geometry", JSONObject().put("type", "Point").put("coordinates", JSONArray().put(camera.point.longitude).put(camera.point.latitude)))
                .put("properties", JSONObject().put("id", camera.id).put("maxspeed", camera.maxSpeed))
            features.put(feature)
        }
        val json = JSONObject().put("type", "FeatureCollection").put("features", features).toString()
        currentStyle?.getSourceAs<GeoJsonSource>(CAMERA_SOURCE)?.setGeoJson(json)
    }

    private fun updateUserMarker(location: Location?) {
        if (location == null) return
        val json = JSONObject()
            .put("type", "FeatureCollection")
            .put("features", JSONArray().put(JSONObject()
                .put("type", "Feature")
                .put("geometry", JSONObject().put("type", "Point").put("coordinates", JSONArray().put(location.longitude).put(location.latitude)))
                .put("properties", JSONObject())))
            .toString()
        currentStyle?.getSourceAs<GeoJsonSource>(USER_SOURCE)?.setGeoJson(json)
    }

    private fun updateNavigationProgress(location: Location) {
        val route = currentRoute ?: return
        if (route.steps.isEmpty() || currentStepIndex !in route.steps.indices) return
        var step = route.steps[currentStepIndex]
        var distance = distanceMeters(location.latitude, location.longitude, step.latitude, step.longitude)
        if (distance < 40.0 && currentStepIndex < route.steps.lastIndex) {
            currentStepIndex += 1
            step = route.steps[currentStepIndex]
            distance = distanceMeters(location.latitude, location.longitude, step.latitude, step.longitude)
            tts?.speak(step.instruction, TextToSpeech.QUEUE_ADD, null, "turn_$currentStepIndex")
        }
        nextTurnText.text = if (step.type == "arrive") step.instruction else "${step.instruction} dalam ${formatDistance(distance)}"
    }

    private fun checkNearbySpeedCameras(location: Location) {
        if (!cameraWarningsEnabled) return
        val nearby = cameraPoints.asSequence()
            .filter { it.id !in warnedCameraIds }
            .map { it to distanceMeters(location.latitude, location.longitude, it.point.latitude, it.point.longitude) }
            .filter { it.second <= CAMERA_ALERT_METERS }
            .minByOrNull { it.second } ?: return
        warnedCameraIds.add(nearby.first.id)
        val distance = nearby.second
        statusText.text = "⚠ Kamera kelajuan berhampiran (${formatDistance(distance)}). Kekalkan had laju."
        tts?.speak("Amaran. Kamera kelajuan dalam kira-kira ${distance.roundToInt()} meter. Kekalkan had laju.", TextToSpeech.QUEUE_ADD, null, "camera_${nearby.first.id}")
    }

    private fun focusOnLocation(location: Location, zoom: Double) {
        map?.animateCamera(
            CameraUpdateFactory.newCameraPosition(
                CameraPosition.Builder()
                    .target(LatLng(location.latitude, location.longitude))
                    .zoom(zoom)
                    .tilt(if (is3D) 55.0 else 0.0)
                    .build()
            ), 600
        )
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ms", "MY"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("en", "US"))
            }
        }
    }

    private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val result = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, result)
        return result[0].toDouble()
    }

    private fun formatDistance(meters: Double): String = if (meters < 1000.0) {
        "${meters.roundToInt()} m"
    } else {
        String.format(Locale("ms", "MY"), "%.1f km", meters / 1000.0)
    }

    private fun formatDuration(seconds: Double): String {
        val minutes = (seconds / 60.0).roundToInt()
        return if (minutes < 60) "$minutes min" else "${minutes / 60} jam ${minutes % 60} min"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    override fun onStart() {
        super.onStart()
        if (::mapView.isInitialized) mapView.onStart()
    }

    override fun onResume() {
        super.onResume()
        if (::mapView.isInitialized) mapView.onResume()
    }

    override fun onPause() {
        if (::mapView.isInitialized) mapView.onPause()
        super.onPause()
    }

    override fun onStop() {
        if (::mapView.isInitialized) mapView.onStop()
        super.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        if (::mapView.isInitialized) mapView.onLowMemory()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::mapView.isInitialized) mapView.onSaveInstanceState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        try { locationManager.removeUpdates(locationListener) } catch (_: Exception) {}
        tts?.stop()
        tts?.shutdown()
        networkExecutor.shutdownNow()
        if (::mapView.isInitialized) mapView.onDestroy()
        super.onDestroy()
    }

    private data class GeoPoint(val latitude: Double, val longitude: Double)
    private data class RouteStep(
        val latitude: Double,
        val longitude: Double,
        val instruction: String,
        val distanceMeters: Double,
        val type: String
    )
    private data class RouteResult(
        val geoJson: String,
        val coordinates: List<GeoPoint>,
        val distanceMeters: Double,
        val durationSeconds: Double,
        val steps: List<RouteStep>
    )
    private data class SpeedCamera(val id: Long, val point: GeoPoint, val maxSpeed: String)
}
