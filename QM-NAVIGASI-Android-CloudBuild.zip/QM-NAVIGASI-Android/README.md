# QM NAVIGASI — Projek Android

Projek prototaip aplikasi navigasi Android menggunakan Kotlin dan MapLibre. Nama paparan aplikasi: **QM NAVIGASI**.

## Ciri dalam prototaip
- Peta dengan perspektif 3D dan bangunan 3D jika disediakan oleh gaya peta.
- GPS telefon dan penanda lokasi semasa.
- Carian destinasi, laluan kereta, jarak dan anggaran masa.
- Arahan belok terperinci dan suara melalui Text-to-Speech.
- Pertanyaan data kamera kelajuan tetap daripada OpenStreetMap serta amaran apabila menghampiri lokasi yang diketahui.
- Kawalan perspektif 3D dan amaran kamera.

## Cara mendapatkan APK melalui GitHub Actions
1. Muat naik kandungan folder ini ke repositori GitHub baharu (pastikan `settings.gradle.kts` berada di akar repositori).
2. Tunggu workflow **Build QM NAVIGASI APK** berjalan secara automatik selepas push, atau buka tab **Actions** dan jalankan secara manual.
3. Buka hasil workflow yang berjaya dan muat turun artifact `QM-NAVIGASI-debug-apk`.
4. Ekstrak ZIP artifact dan pindahkan `app-debug.apk` ke telefon Android.
5. Buka APK dan benarkan pemasangan daripada sumber tersebut jika Android memintanya. Kemudian benarkan kebenaran lokasi dan pastikan internet aktif.

Workflow GitHub Actions disertakan di `.github/workflows/build-apk.yml`. Ia membina APK debug yang boleh dipasang untuk ujian; ia bukan keluaran bertandatangan produksi untuk Google Play.

## Cara bina dengan Android Studio
1. Pasang Android Studio, Android SDK Platform 36 dan JDK 17.
2. Buka folder projek ini dalam Android Studio.
3. Sync Gradle, kemudian pilih **Build > Build APK(s)**.
4. Jika binaan berjaya, APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Perkhidmatan rangkaian yang digunakan
- Peta: OpenFreeMap (`https://tiles.openfreemap.org/styles/liberty`).
- Geocoding: Nominatim/OpenStreetMap.
- Laluan: pelayan demonstrasi OSRM.
- Kamera kelajuan: Overpass API dengan data `highway=speed_camera` daripada OpenStreetMap.

## Batasan penting
**APK belum dibina atau diuji dalam persekitaran penyediaan ini.** Workflow di atas menyediakan pembinaan awan; kejayaan binaan perlu disahkan dalam GitHub Actions sebelum APK dimuat turun. Aplikasi memerlukan internet untuk peta, carian destinasi, penghalaan dan data kamera. Pelayan demo mungkin mempunyai had kadar atau gangguan. Data kamera tidak rasmi, boleh tidak lengkap atau lapuk, dan tidak menjamin semua kamera AwAS di Malaysia. Patuhi papan tanda serta had laju sebenar dan jangan kendalikan telefon ketika memandu.

## Rujukan
- MapLibre Android: https://maplibre.org/maplibre-native/android/
- OpenFreeMap: https://openfreemap.org/quick_start/
- OSRM API: https://project-osrm.org/docs/v5.5.1/api/
- Nominatim policy: https://operations.osmfoundation.org/policies/nominatim/
- Overpass API: https://wiki.openstreetmap.org/wiki/Overpass_API
- OSM speed camera tag: https://wiki.openstreetmap.org/wiki/Tag:highway%3Dspeed_camera
