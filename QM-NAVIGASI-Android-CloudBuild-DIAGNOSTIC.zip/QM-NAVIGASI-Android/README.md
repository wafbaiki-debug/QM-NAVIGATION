# QM NAVIGASI — Android APK

Projek Android Kotlin menggunakan MapLibre untuk peta, lokasi GPS, carian destinasi, panduan laluan, arahan suara dan penanda/amaran kamera kelajuan berdasarkan data OpenStreetMap.

## Cara bina APK menggunakan GitHub Actions

1. Ekstrak ZIP ini. Pastikan fail `settings.gradle.kts`, `build.gradle.kts`, folder `app/` dan folder tersembunyi `.github/` berada terus di akar repositori GitHub (bukan di dalam satu folder tambahan).
2. Muat naik semua fail dan folder tersebut ke repositori `QM-NAVIGATION` pada branch `main`, termasuk `.github/workflows/build-apk.yml`.
3. Buka tab **Actions** pada repositori. Pilih **Build QM NAVIGASI APK**.
4. Tekan **Run workflow** dan pilih branch `main`.
5. Tunggu job selesai. Jika berjaya, buka workflow run dan muat turun artifact **QM-NAVIGASI-debug-apk**.
6. Ekstrak artifact tersebut untuk mendapatkan `app-debug.apk`, kemudian pindahkan ke telefon Android dan benarkan pemasangan dari sumber ini apabila diminta.

## Persekitaran binaan

Workflow menggunakan Java 17, Gradle 8.11.1, Android SDK Platform 36 dan Build Tools 36.0.0.

## Had dan keselamatan

- APK yang dihasilkan ialah debug APK untuk ujian, bukan release APK untuk edaran awam.
- Aplikasi memerlukan sambungan internet untuk peta, carian alamat, penghalaan dan data kamera.
- Data kamera kelajuan daripada OpenStreetMap mungkin tidak lengkap atau tidak terkini. Patuhi papan tanda dan had laju rasmi.
- Binaan belum disahkan dalam persekitaran ini; semak log GitHub Actions untuk sebarang ralat kompilasi.
